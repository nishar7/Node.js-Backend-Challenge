const express = require("express");
const user_route = express();

user_route.set('view engine', 'ejs');
user_route.set('views', './views/users');

const bodyParser = require('body-parser');
user_route.use(bodyParser.json());
user_route.use(bodyParser.urlencoded({extended:true}))

const multer = require("multer");
const path = require("path");

user_route.use(expres.static('public'));

const storage = multer.diskStorage({
    destination:function(req,file,cb){
        cb(null, path.join(___dirname, '/public/userImages'));
    },
    filename:function(){
        const name = Date.now() + '-'+file.originalname;
        cb(null,name);
    }
});
const upload = multer ({storage : storage});
const usercontoller = require("../controllers/userController");

user_route.get('/register', usercontoller.loadRegister);

user_route.post('/register', upload.single('image'),usercontoller.insertUser);

user_route.get('/', usercontoller.loginLoad);
user_route.get('/login', usercontoller.loginLoad);

user_route.get('/logout', auth.isLogin, userController.userLogout);
user_route.get('/home', auth.isLogin, usercontoller.loadHome);

user_route.get('/edit', auth.isLogin, usercontoller.editLoad);

user_route.post('/edit', upload.single('image'), userContoller.updateProfile);

module.exports = user_route;
